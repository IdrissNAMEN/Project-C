// + = SOL
// * = ARBRE
//   = FEUILLE
// # = ROCHE
// x = HERBE
// / = EAU
// - = CENDRES
// @ = CENDRE ETEINTES

#include <stdio.h>
#include <stdlib.h>


#define SOL '+'
#define ARBRE '*'
#define FEUILLE ' '
#define ROCHE '#'
#define HERBE 'x'
#define EAU '/'
#define CENDRES '-'
#define CENDRES_ETEINTES '@'

void lancerFeu(int x, int y, char **matrice, int *degres, int *etats) {
  char typeCellule = matrice[x][y];
  
  
  if (etats[typeCellule] == 1 && degres[typeCellule] == 2) {
    matrice[x][y] = '-';
    degres[typeCellule] = degres[CENDRES]; 
    printf("Feu lancé sur la position [%d][%d]\n", x, y);
    printf("Mise à jour du degré : %d\n", degres[typeCellule]);
    
  }
  
  if (etats[typeCellule] == 1 && degres[typeCellule] > 2) {
    printf("Feu lancé sur la position [%d][%d]\n", x, y);
    degres[typeCellule]--; // Diminuer le degré
    printf("Mise à jour du degré : %d\n", degres[typeCellule]);
  }
    
  if (matrice[x][y] == '-') {
    printf("Feu lancé sur la position [%d][%d]\n", x, y);
    degres[typeCellule] = degres[CENDRES_ETEINTES];
    etats[typeCellule] = etats[CENDRES_ETEINTES];
    printf("Position [%d] [%d] : Mise à jour du degré : %d || Mise à jour de l'état (1 = en feu, 0 = pas en feu) : %d \n",x, y, degres[typeCellule], etats[typeCellule]);
    matrice[x][y] = '@'; // Transformation de la cendre en cendre éteinte
  }

  
}




int main(void) {
  char nom[50];
  int longueur, largeur;
  char **matrice = NULL;
  int i, j;
 
 
  printf ("Entrez le nom de l'utilisateur : ");
  scanf ("%s", &nom);
  printf("Bonjour %s ! \n", nom);
 
  printf ("Entrez la longueur de la forêt : ");
  scanf ("%d", &longueur);
  printf ("Entrez la largeur de la forêt : ");
  scanf ("%d", &largeur);
 
  // Allocation Matrice
  matrice = malloc(longueur * sizeof(char*));
 
  for (i = 0; i < longueur; i++) {
    matrice[i] = malloc(largeur * sizeof(char));
  }
 
  // Entrée des valeurs
  for (i = 0; i < longueur; i++) {
    for (j = 0; j < largeur; j++) {
      printf("Entrez la valeur pour [%d][%d] ", i, j);
      scanf(" %c", &matrice[i][j]);
    }
  }
  
  
  int degres[128] = {0}; // Initialisés à zéro
  int etats[128] = {0};  // Initialisés à zéro
  degres[SOL] = 0;
  degres[ARBRE] = 4;
  degres[FEUILLE] = 2;
  degres[ROCHE] = 5;
  degres[HERBE] = 3;
  degres[EAU] = 0;
  degres[CENDRES] = 1;
  degres[CENDRES_ETEINTES] = 0;
  
  
 
  // Affichage de la forêt
  for (i = 0; i < longueur; i++) {
    for (j = 0; j < largeur; j++) {
      printf("+---");
    }
    printf("+\n");

    for (j = 0; j < largeur; j++) {
      printf("| ");
        switch (matrice[i][j]) {
            case '+':
                printf("+ ");
                break;
            case '*':
                printf("* ");
                break;
            case ' ':
                printf("  ");
                break;
            case '#':
                printf("# ");
                break;
            case 'x':
                printf("x ");
                break;
            case 'X':
                printf("x ");
                break;
            case '/':
                printf("/ ");
                break;
            case '-':
                printf("- ");
                break;
            case '@':
                printf("@ ");
                break;
            default:
                printf("INCONNU ");
        }
    }
    printf("|\n");


  for (j = 0; j < largeur; j++) {
   printf("+---");
  }
  printf("+\n");
 
 
 
  // Etat de chaque cellule
  int degre;
  if (matrice[i][j] == '+') {
    degre = 0;
  }
  if (matrice[i][j] == '*') {
    degre = 4;
  }
  if (matrice[i][j] == ' ') {
    degre = 2;
  }
  if (matrice[i][j] == '#') {
    degre = 5;
  }
  if (matrice[i][j] == 'x') {
    degre = 3;
  }
  if (matrice[i][j] == '/') {
    degre = 0;
  }
  if (matrice[i][j] == '-') {
    degre = 1;
  }
  if (matrice[i][j] == '@') {
    degre = 0;
  }
  }
 

 
  //Effet propagation du feu
  int x, y;
  printf("Entrez la position x dans laquelle le feu se propagera : ");
  scanf("%d", &x);
  printf("Entrez la position y dans laquelle le feu se propagera : ");
  scanf("%d", &y);
  lancerFeu(x, y, matrice, degres, etats);
 
    // Affichage de la nouvelle forêt
  printf ("Mise à jour de la forêt : \n");
  for (i = 0; i < longueur; i++) {
    for (j = 0; j < largeur; j++) {
      printf("+---");
    }
    printf("+\n");

    for (j = 0; j < largeur; j++) {
      printf("| ");
        switch (matrice[i][j]) {
            case '+':
                printf("+ ");
                break;
            case '*':
                printf("* ");
                break;
            case ' ':
                printf("  ");
                break;
            case '#':
                printf("# ");
                break;
            case 'x':
                printf("x ");
                break;
            case 'X':
                printf("x ");
                break;
            case '/':
                printf("/ ");
                break;
            case '-':
                printf("- ");
                break;
            case '@':
                printf("@ ");
                break;
            default:
                printf("INCONNU ");
        }
    }
    printf("|\n");


  for (j = 0; j < largeur; j++) {
   printf("+---");
  }
  printf("+\n");
  }
  

 
       
  // Destruction Matrice
  for (i = 0; i < longueur; i++) {
    free(matrice[i]);
    matrice[i] = NULL;
  }
 
  free(matrice);
  matrice = NULL;
 
  return 0;
}